﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROYECT
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string result = "";
            string result2 = "";
            if (!(MEDICAMENTO.Text.All(Char.IsLetter)))
            {
                MessageBox.Show("El nombre del medicamento sólo debe contener letras");
            }
            else
            {
                if (String.IsNullOrEmpty(MEDICAMENTO.Text))
                {
                    MessageBox.Show("Debe introducir el nombre del medicamento");
                }
                else
                {
                    if (String.IsNullOrEmpty(tipomedicamento.Text))
                    {
                        MessageBox.Show("Debe seleccionar el tipo de medicamento");

                    }else
                    {
                        if (!rb1.IsChecked.Value)
                        {
                            if (!rb2.IsChecked.Value)
                            {
                                if (!rb3.IsChecked.Value)
                                {
                                    MessageBox.Show("Debe seleccionar el distribuidor");
                                }
                                else
                                {
                                    result = "CEMEFAR";
                                }
                            }
                            else
                            {
                                result = "EMPSEPHAR";
                            }
                        }
                        else
                        {
                            result = "COFARMA";

                        }
                        if (!cb1.IsChecked.Value)
                        {
                            if (!cb2.IsChecked.Value)
                            {
                                MessageBox.Show("Debe seleccionar la surcursal");
                            }
                            else
                            {
                                result2 = "SECUNDARIO";
                            }
                        }
                        else
                        {
                            result2 = "PRINCIPAL";
                        }
                        if(result!="" && result2 != "")
                        {

                            Window1 pt2 = new Window1();
                            pt2.nombremedicamento.Text = MEDICAMENTO.Text;
                            pt2.nombremedicamento.IsEnabled = false;
                            pt2.tipo.Text = tipomedicamento.Text;
                            pt2.tipo.IsEnabled = false;
                            pt2.distribuidor.Text = result;
                            pt2.distribuidor.IsEnabled = false;
                            pt2.sucursal.Text = result2;
                            pt2.sucursal.IsEnabled = false;
                            pt2.cantidad.Text = cantidad.Text;
                            pt2.cantidad.IsEnabled = false;
                            this.Hide();
                            pt2.Show();
                        }

                    }
                }
            }
            
            
           

        }

        private void Cantidad_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(cantidad.Text, "[^0-9]"))
            {
                MessageBox.Show("DEBE INGRESAR SOLO NUMEROS");
                cantidad.Text = cantidad.Text.Remove(cantidad.Text.Length - 1);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MEDICAMENTO.Text="";
            tipomedicamento.Text = "";
            cantidad.Text = "";
            rb1.IsChecked = false;
            rb2.IsChecked = false;
            rb3.IsChecked = false;
            cb1.IsChecked = false;
            cb2.IsChecked = false;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
